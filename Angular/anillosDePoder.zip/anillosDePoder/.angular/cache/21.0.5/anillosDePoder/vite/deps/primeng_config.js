import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-IUNX3DYM.js";
import "./chunk-CGMOMKBT.js";
import "./chunk-BHWAUKBD.js";
import "./chunk-ZMFEXUGK.js";
import "./chunk-H44XD2L2.js";
import "./chunk-3WIGXD6M.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-GOMI4DH3.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
